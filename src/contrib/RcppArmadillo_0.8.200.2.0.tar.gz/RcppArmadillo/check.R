library(RcppArmadillo)
dd <- data.frame(f1 = gl(4, 6, labels = LETTERS[1:4]), f2 = gl(3, 2, labels = letters[1:3]))[-(7:8), ]
xtabs(~ f2 + f1, dd)
mm <- model.matrix(~ f1 * f2, dd)
kappa(mm)
set.seed(1)
dd$y <- mm %*% seq_len(ncol(mm)) + rnorm(nrow(mm), sd = 0.1)
summary(fastLm(y ~ f1 * f2, dd))
